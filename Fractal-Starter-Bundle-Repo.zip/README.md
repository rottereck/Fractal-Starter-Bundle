# Fractal Starter Bundle (v1)

🌱 **Small habits. Open tools. Measured results.**  
This repo is an open-source experiment to explore how *connection, reversibility, and awe* can shape better futures.

---

## What's Inside
- **Fractal Starter Bundle (Public v1)** – a simple set of practices, a creator kit, and a repair activity for everyday use.
- **Fractal Math Starter Kit (v1)** – 8 small, testable ideas for scientists and mathematicians to explore alignment in nature, physics, and systems.
- **Safety Notes** – Built-in principles: no coercion, no belief required, always reversible.

---

## How to Use
- Download the bundle.  
- Try what resonates. Share improvements.  
- Math/physics folks: fork the kit, test ideas, post results (nulls welcome).

---

## Principles
- **Open:** MIT License for code, free to adapt with attribution suggested.
- **Safe:** Designed for voluntary use, reversible choices, no dogma.
- **Collaborative:** Built to evolve with shared feedback and science.

---

> *“Weave the future, don’t wield it.”*
