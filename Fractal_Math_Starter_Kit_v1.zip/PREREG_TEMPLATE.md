# PREREG TEMPLATE
Title:
Date:
Hypothesis:
Primary outcomes:
Null:
Data source:
Analysis plan:
Quality checks:
Reporting:
