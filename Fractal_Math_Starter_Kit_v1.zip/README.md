# Fractal Math Starter Kit (v1)
This kit proposes 8 testable entry points for exploring fractal alignment ideas via existing math/physics models.

Contents:
- EQUATIONS.md: compact math forms and test notes.
- ONEPAGER_Math_Entry_Points.md: plain-language goals.
- PREREG_TEMPLATE.md: prereg skeleton.
- code/: Python stubs with synthetic data demos.

License: CC-BY 4.0 (attribution, keep safety notes).
