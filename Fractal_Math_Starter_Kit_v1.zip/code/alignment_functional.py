print('Demo alignment score: 0.7')
