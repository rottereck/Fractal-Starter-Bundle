print('Demo closure index synthetic: 1.5')
