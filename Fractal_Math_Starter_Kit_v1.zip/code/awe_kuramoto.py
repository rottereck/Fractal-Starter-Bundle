print('Demo Kuramoto awe simulation order param')
