print('Demo cosmic connection bias slope ~0.05 synthetic')
