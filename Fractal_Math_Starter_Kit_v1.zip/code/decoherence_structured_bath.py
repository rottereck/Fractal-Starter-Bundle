print('Demo structured bath synthetic fit')
