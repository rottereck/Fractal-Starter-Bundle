print('Demo entanglement-order coupling synthetic fit')
