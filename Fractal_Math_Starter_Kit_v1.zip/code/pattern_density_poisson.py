print('Demo pattern density synthetic events')
