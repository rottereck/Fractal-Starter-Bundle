print('Demo efficiency proxy')
